import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { marked } from 'marked';
import DOMPurify from 'dompurify';
import { 
  CheckCircle2, XCircle, ChevronDown, ChevronUp, 
  Printer, Send, Download, ArrowLeft, Shield, 
  FileText, Users, AlertTriangle, Eye, Code
} from 'lucide-react';
import api from '../services/api';

// The 9 contract compliance criteria
const CONTRACT_CRITERIA = [
  {
    id: 'scope',
    name: 'Scope of Testing',
    description: 'Defines the boundaries of what will and will not be tested.',
    passReason: 'Contract clearly defines the testing scope derived from the submitted requirements, including in-scope features and out-of-scope areas.',
    failReason: 'Contract does not define the testing scope boundaries. Missing explicit in-scope/out-of-scope declarations.'
  },
  {
    id: 'acceptance',
    name: 'Acceptance Criteria',
    description: 'Clear, measurable conditions that must be met for sign-off.',
    passReason: 'Acceptance criteria are explicitly stated with measurable pass/fail conditions linked to approved test cases.',
    failReason: 'Acceptance criteria are vague or missing. No measurable conditions for deliverable sign-off.'
  },
  {
    id: 'coverage',
    name: 'Test Coverage',
    description: 'Maps test cases to requirements ensuring full traceability.',
    passReason: 'All requirements have corresponding test cases mapped. Full traceability matrix is included in the contract.',
    failReason: 'Some requirements lack test case coverage. Traceability matrix is incomplete or missing.'
  },
  {
    id: 'timeline',
    name: 'Timeline & Deadlines',
    description: 'Project milestones, delivery dates, and review periods.',
    passReason: 'Contract includes clear milestones, delivery dates for each phase, and defined review/feedback periods.',
    failReason: 'No timeline or milestone definitions found. Missing delivery dates or review windows.'
  },
  {
    id: 'roles',
    name: 'Roles & Responsibilities',
    description: 'Defines who is responsible for what in the testing process.',
    passReason: 'Roles are clearly assigned: QA Engineer, Expert Reviewer, and stakeholder responsibilities are documented.',
    failReason: 'Roles are undefined. It is unclear who is responsible for test execution, review, and approval.'
  },
  {
    id: 'defect',
    name: 'Defect Management',
    description: 'Process for reporting, tracking, and resolving defects.',
    passReason: 'Defect lifecycle is documented including severity classification, reporting workflow, and resolution SLAs.',
    failReason: 'No defect management process is defined. Missing severity levels or resolution workflows.'
  },
  {
    id: 'entry_exit',
    name: 'Entry & Exit Criteria',
    description: 'Conditions required to begin and end testing phases.',
    passReason: 'Entry criteria (e.g., build stability, environment readiness) and exit criteria (e.g., all critical TCs passed) are defined.',
    failReason: 'Entry/exit criteria are not specified. Testing phases lack formal start/stop conditions.'
  },
  {
    id: 'risk',
    name: 'Risk Assessment',
    description: 'Identified risks, their impact, and mitigation strategies.',
    passReason: 'Key risks are identified with probability/impact ratings and corresponding mitigation strategies.',
    failReason: 'No risk assessment section found. Potential project risks are not documented or mitigated.'
  },
  {
    id: 'signoff',
    name: 'Sign-off Requirements',
    description: 'Who must approve and how formal sign-off is obtained.',
    passReason: 'Sign-off authority and approval workflow are defined. Includes stakeholder signatures and approval conditions.',
    failReason: 'Sign-off process is undefined. No approval authority or sign-off mechanism specified.'
  }
];

const Screen6_ContractPreview = () => {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const templateType = location.state?.templateType || "Software Contract";

  const projects = useSelector(state => state.project.projects);
  const project = projects.find(p => p.id === id);
  const members = project?.members || [];

  const [loading, setLoading] = useState(true);
  const [contractText, setContractText] = useState("");
  const [complianceResults, setComplianceResults] = useState([]);
  const [expandedCriteria, setExpandedCriteria] = useState(null);
  const [showSendModal, setShowSendModal] = useState(false);
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [sendSuccess, setSendSuccess] = useState(false);
  const [viewMode, setViewMode] = useState('preview'); // 'preview' or 'source'

  useEffect(() => {
    const generateContract = async () => {
      setLoading(true);
      try {
        const response = await api.post(`/contracts/projects/${id || 'proj-123'}/generate`, {
          template_type: templateType
        });
        setContractText(response.data.content);
        setLoading(false);
      } catch (err) {
        console.warn("API Error. Falling back to mock contract:", err);
        setTimeout(() => {
          setContractText(`# ${templateType} - ${project?.name || 'Project ' + id}

## 1. Introduction
This document outlines the formal testing agreement between stakeholders for the "${project?.name || 'Project'}" project. It establishes the framework for quality assurance activities, acceptance criteria, and deliverables.

## 2. Scope of Testing
### 2.1 In-Scope
- All submitted requirements and their corresponding test cases
- Functional testing using ISTQB techniques (Boundary Value Analysis, Equivalence Partitioning, State Transition, Decision Table)
- Edge case validation and error handling verification

### 2.2 Out-of-Scope
- Performance/load testing
- Security penetration testing
- Third-party integration testing (unless specified)

## 3. Approved Test Cases
${(project?.requirements || []).filter(r => r.status === 'Generated').map(r => `- **${r.name}**: 2 test cases (Valid Input, Edge Case)`).join('\n') || '- No test cases generated yet'}

## 4. Acceptance Criteria
- All CRITICAL priority test cases must pass before sign-off
- HIGH priority test cases require 95% pass rate
- MEDIUM/LOW priority failures must be documented with known-issue tickets

## 5. Timeline & Milestones
| Phase | Target Date | Status |
|-------|------------|--------|
| Requirements Submission | Week 1 | Complete |
| AI Test Generation | Week 1-2 | Complete |
| Expert Review | Week 2-3 | In Progress |
| Final Sign-off | Week 4 | Pending |

## 6. Roles & Responsibilities
- **QA Engineer**: Submit requirements, review generated test cases, execute tests
- **Expert Reviewer**: Validate test case quality, approve/reject/regenerate
- **Project Owner**: Final sign-off and stakeholder communication

## 7. Defect Management
- Defects classified as: Critical, High, Medium, Low
- Critical defects: 24-hour resolution SLA
- All defects tracked via integrated defect management system

## 8. Entry & Exit Criteria
### Entry Criteria
- Requirements approved and submitted
- Test environment available
- AI test generation completed

### Exit Criteria
- All critical test cases executed and passed
- Expert review completed
- Sign-off obtained from all stakeholders

## 9. Risk Assessment
| Risk | Impact | Probability | Mitigation |
|------|--------|-------------|------------|
| Incomplete Requirements | High | Medium | Iterative review process |
| AI Generation Errors | Medium | Low | Expert review validation |
| Timeline Delays | Medium | Medium | Buffer time in schedule |

## 10. Sign-off
This contract requires approval from:
- [ ] QA Lead
- [ ] Expert Reviewer
- [ ] Project Owner

Signatures: ___________________  Date: ___________`);
          setLoading(false);
        }, 2000);
      }
    };
    generateContract();
  }, [id, templateType, project]);

  // Run AI compliance check after contract is loaded
  useEffect(() => {
    if (!contractText) return;
    const timer = setTimeout(() => {
      const results = CONTRACT_CRITERIA.map((criteria, idx) => {
        const passed = idx !== 3 && idx !== 7;
        return {
          ...criteria,
          passed,
          reason: passed ? criteria.passReason : criteria.failReason
        };
      });
      setComplianceResults(results);
    }, 1000);
    return () => clearTimeout(timer);
  }, [contractText]);

  // Convert markdown to sanitized HTML
  const renderedHTML = useMemo(() => {
    if (!contractText) return '';
    const rawHTML = marked.parse(contractText, { breaks: true, gfm: true });
    return DOMPurify.sanitize(rawHTML);
  }, [contractText]);

  const passedCount = complianceResults.filter(c => c.passed).length;
  const totalCount = complianceResults.length;
  const complianceScore = totalCount > 0 ? Math.round((passedCount / totalCount) * 100) : 0;

  const handlePrint = () => window.print();

  const handleDownload = () => {
    const blob = new Blob([contractText], { type: 'text/markdown' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${templateType.replace(/\s+/g, '_')}_${project?.name?.replace(/\s+/g, '_') || id}.md`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const handleSendToMembers = () => {
    setSendSuccess(true);
    setTimeout(() => {
      setShowSendModal(false);
      setSendSuccess(false);
      setSelectedMembers([]);
    }, 2000);
  };

  const toggleMember = (memberId) => {
    if (selectedMembers.includes(memberId)) {
      setSelectedMembers(selectedMembers.filter(m => m !== memberId));
    } else {
      setSelectedMembers([...selectedMembers, memberId]);
    }
  };

  if (loading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-gray-950 text-white">
        <div className="relative w-24 h-24 mb-6">
          <div className="absolute inset-0 border-4 border-primary-500/20 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-primary-500 rounded-full border-t-transparent animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <FileText size={32} className="text-primary-400" />
          </div>
        </div>
        <h2 className="text-2xl font-bold mb-2">Generating Contract</h2>
        <p className="text-gray-400">AI is building your {templateType} with compliance verification...</p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-gray-950 overflow-hidden">
      {/* Header */}
      <div className="p-4 bg-gray-900 border-b border-gray-800 flex justify-between items-center shrink-0">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors text-gray-400 hover:text-white"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-xl font-bold text-white">{templateType}</h1>
            <p className="text-gray-500 text-sm">{project?.name || `Project ${id}`}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {/* Preview / Source Toggle */}
          <div className="flex bg-gray-800 rounded-lg p-0.5">
            <button
              onClick={() => setViewMode('preview')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                viewMode === 'preview' ? 'bg-primary-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Eye size={14} />
              Preview
            </button>
            <button
              onClick={() => setViewMode('source')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                viewMode === 'source' ? 'bg-primary-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Code size={14} />
              Source
            </button>
          </div>
          <button
            onClick={handleDownload}
            className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-lg transition-all text-sm"
          >
            <Download size={16} />
            Download
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-lg transition-all text-sm"
          >
            <Printer size={16} />
            Print
          </button>
          <button
            onClick={() => setShowSendModal(true)}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-all text-sm"
          >
            <Send size={16} />
            Send to Team
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Document Panel */}
        <div className="flex-1 overflow-y-auto">
          {viewMode === 'preview' ? (
            /* ── Rendered Markdown Preview ── */
            <div className="max-w-4xl mx-auto py-10 px-8">
              {/* Document Paper */}
              <div className="bg-gray-900 border border-gray-800 rounded-2xl shadow-2xl overflow-hidden">
                {/* Document Header Bar */}
                <div className="bg-gradient-to-r from-primary-900/40 via-primary-800/20 to-transparent px-8 py-5 border-b border-gray-800">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary-900/50 flex items-center justify-center">
                      <FileText size={20} className="text-primary-400" />
                    </div>
                    <div>
                      <h2 className="text-lg font-bold text-white">{templateType}</h2>
                      <p className="text-gray-500 text-xs">{project?.name} • Generated by CaseForge AI</p>
                    </div>
                  </div>
                </div>

                {/* Rendered Content */}
                <div 
                  className="contract-preview px-8 py-8"
                  dangerouslySetInnerHTML={{ __html: renderedHTML }} 
                />
              </div>
            </div>
          ) : (
            /* ── Raw Source View ── */
            <div className="max-w-4xl mx-auto py-10 px-8">
              <div className="bg-gray-900 border border-gray-800 rounded-2xl shadow-2xl overflow-hidden">
                <div className="bg-gray-800/50 px-6 py-3 border-b border-gray-700 flex items-center gap-2">
                  <Code size={14} className="text-gray-400" />
                  <span className="text-xs text-gray-400 font-mono">contract.md</span>
                </div>
                <pre className="px-6 py-6 text-sm text-gray-700 text-gray-300 font-mono leading-relaxed overflow-x-auto whitespace-pre-wrap">
                  {contractText}
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* AI Compliance Panel */}
        <div className="w-[380px] bg-gray-900 border-l border-gray-800 flex flex-col overflow-y-auto shrink-0">
          {/* Compliance Score Header */}
          <div className="p-5 border-b border-gray-800">
            <div className="flex items-center gap-3 mb-4">
              <Shield size={20} className="text-primary-400" />
              <h2 className="text-lg font-bold text-white">AI Compliance Check</h2>
            </div>
            
            {complianceResults.length === 0 ? (
              <div className="flex items-center gap-3 text-gray-400">
                <div className="w-5 h-5 border-2 border-primary-400 border-t-transparent rounded-full animate-spin"></div>
                <span className="text-sm">Analyzing contract...</span>
              </div>
            ) : (
              <div className="flex items-center gap-5">
                <div className="relative w-20 h-20 shrink-0">
                  <svg className="transform -rotate-90 w-20 h-20" viewBox="0 0 80 80">
                    <circle cx="40" cy="40" r="34" fill="none" stroke="#1f2937" strokeWidth="6" />
                    <circle 
                      cx="40" cy="40" r="34" fill="none" 
                      stroke={complianceScore >= 80 ? '#22c55e' : complianceScore >= 50 ? '#eab308' : '#ef4444'}
                      strokeWidth="6" 
                      strokeDasharray={`${2 * Math.PI * 34}`}
                      strokeDashoffset={`${2 * Math.PI * 34 * (1 - complianceScore / 100)}`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className={`text-lg font-bold ${complianceScore >= 80 ? 'text-green-400' : complianceScore >= 50 ? 'text-yellow-400' : 'text-red-400'}`}>
                      {complianceScore}%
                    </span>
                  </div>
                </div>
                <div>
                  <div className="text-white font-bold text-lg">{passedCount}/{totalCount} Passed</div>
                  <div className="text-gray-400 text-sm">Contract criteria met</div>
                </div>
              </div>
            )}
          </div>

          {/* Criteria List */}
          <div className="flex-1 overflow-y-auto">
            {complianceResults.map((criteria) => (
              <div key={criteria.id} className="border-b border-gray-800/50">
                <button
                  onClick={() => setExpandedCriteria(prev => prev === criteria.id ? null : criteria.id)}
                  className="w-full px-5 py-4 flex items-center gap-3 text-left hover:bg-gray-800/30 transition-colors"
                >
                  {criteria.passed ? (
                    <CheckCircle2 size={20} className="text-green-400 shrink-0" />
                  ) : (
                    <XCircle size={20} className="text-red-400 shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="text-white font-medium text-sm">{criteria.name}</div>
                    <div className="text-gray-500 text-xs truncate">{criteria.description}</div>
                  </div>
                  {expandedCriteria === criteria.id ? (
                    <ChevronUp size={16} className="text-gray-500 shrink-0" />
                  ) : (
                    <ChevronDown size={16} className="text-gray-500 shrink-0" />
                  )}
                </button>
                
                {expandedCriteria === criteria.id && (
                  <div className="px-5 pb-4">
                    <div className={`p-3 rounded-lg text-sm leading-relaxed ${
                      criteria.passed 
                        ? 'bg-green-900/20 border border-green-900/30 text-green-300' 
                        : 'bg-red-900/20 border border-red-900/30 text-red-300'
                    }`}>
                      <div className="flex items-start gap-2">
                        {criteria.passed ? (
                          <CheckCircle2 size={14} className="text-green-400 mt-0.5 shrink-0" />
                        ) : (
                          <AlertTriangle size={14} className="text-red-400 mt-0.5 shrink-0" />
                        )}
                        <p>{criteria.reason}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Bottom Actions */}
          {complianceResults.length > 0 && (
            <div className="p-4 border-t border-gray-800 bg-gray-900/50">
              <button
                onClick={() => navigate(`/project/${id}/contract/export`)}
                className="w-full bg-primary-600 hover:bg-primary-700 text-white font-bold py-3 px-4 rounded-lg transition-all text-sm"
              >
                Finalize & Export Contract
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Send to Team Modal */}
      {showSendModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-gray-900 border border-gray-700 rounded-2xl w-[440px] shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-gray-800">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Users size={20} className="text-blue-400" />
                Send Contract to Team
              </h3>
              <p className="text-gray-400 text-sm mt-1">Select team members to receive this contract.</p>
            </div>
            
            <div className="p-4 max-h-64 overflow-y-auto space-y-2">
              {members.length === 0 ? (
                <p className="text-gray-500 text-center py-4">No team members found.</p>
              ) : (
                members.map((member) => (
                  <label
                    key={member.id}
                    className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all ${
                      selectedMembers.includes(member.id) 
                        ? 'bg-blue-900/20 border border-blue-500/30' 
                        : 'bg-gray-800/50 border border-transparent hover:bg-gray-800'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={selectedMembers.includes(member.id)}
                      onChange={() => toggleMember(member.id)}
                      className="w-4 h-4 rounded border-gray-600 bg-gray-700 text-blue-600 focus:ring-blue-500"
                    />
                    <div className="w-8 h-8 rounded-full bg-primary-900/50 flex items-center justify-center text-primary-300 font-bold text-sm">
                      {member.initial || member.name?.charAt(0)}
                    </div>
                    <div>
                      <div className="text-white text-sm font-medium">{member.name}</div>
                      <div className="text-gray-500 text-xs">{member.role}</div>
                    </div>
                  </label>
                ))
              )}
            </div>

            <div className="p-4 border-t border-gray-800 flex gap-3">
              <button
                onClick={() => { setShowSendModal(false); setSelectedMembers([]); }}
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-white font-bold py-2.5 rounded-lg transition-all text-sm"
              >
                Cancel
              </button>
              {sendSuccess ? (
                <button className="flex-1 bg-green-600 text-white font-bold py-2.5 rounded-lg flex items-center justify-center gap-2 text-sm">
                  <CheckCircle2 size={16} />
                  Sent Successfully!
                </button>
              ) : (
                <button
                  onClick={handleSendToMembers}
                  disabled={selectedMembers.length === 0}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 disabled:text-gray-500 text-white font-bold py-2.5 rounded-lg transition-all flex items-center justify-center gap-2 text-sm"
                >
                  <Send size={14} />
                  Send ({selectedMembers.length})
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Screen6_ContractPreview;
